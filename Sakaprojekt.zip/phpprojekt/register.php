<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Register page</title>
</head>

<body class="main">
    <div>
        <header>
            <h1>Jojo's bizzare advantures <img src="images/menacing.png"></h1>
            <section class="login">
                <?php
                    error_reporting(E_ALL & ~E_NOTICE); 
                    session_start();
                    if($_SESSION['power'] == "none") {
                        echo'<form method="post" action="login.php">
                                <button type="submit" value="login">Login</button>
                            </form>
                            <form method="post" action="register.php">
                                <button type="submit" value="register">Register</button>
                            </form>';
                    }
                    else {
                        echo $_SESSION['username'];
                        if(isset($_POST['logout'])) {
                            $_SESSION['power'] = "none";
                            echo("<meta http-equiv='refresh' content='1'>");
                        }

                        echo '<form method="post"> 
                                <button type ="submit" id="logout" name="logout" value="logout">Logout</button>
                            </form>';
                        
                    }
                ?>
                
            </section> <br>
            <nav>
                <ul>
                <?php 
                    if($_SESSION['power'] == "none" || $_SESSION['power'] == "user") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>';
                    }
                    else if($_SESSION['power'] == "admin") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>
                        <a href="unos.php"><li>Input</li></a>
                        <a href="admin.php"><li>Administration</li></a>';
                    }
                ?>
                </ul>
            </nav>
        </header>

        <section class="reg">
            <form method="post">
                <label for="username">Username:</label> <br>
                <input type="text" name="username" id="username"> <br>
                <span id="usernameerror"></span>

                <label for="name">Name:</label> <br>
                <input type="text" name="name" id="name"> <br>
                <span id="nameerror"></span>

                <label for="surname">Surname:</label> <br>
                <input type="text" name="surname" id="surname"> <br>
                <span id="surnameerror"></span>

                <label for="password">Password:</label> <br>
                <input type="password" name="password" id="password"> <br>
                <span id="passworderror"></span>

                <label for="passwordR">Retype password:</label> <br>
                <input type="password" name="passwordR" id="passwordR"> <br>
                <span id="passwordRerror"></span>

                <button type="reset" value="reset">Reset</button>
                <button type="submit" id="gumb" name="gumb" value="accept">Accept</button>
            </form>

            <script type="text/javascript">
                document.getElementById("gumb").onclick = function (event) {
                    var slanje_forme = true;

                    var userField = document.getElementById("username");
                    var user = document.getElementById("username").value;
                    if(user.length == 0) {
                        slanje_forme = false;
                        userField.style.border = "1px dashed red";
                        document.getElementById("usernameerror").innerHTML="Username is required!<br>";
                    }
                    else{
                        userField.style.border = "1px solid green"; 
                        document.getElementById("usernameerror").innerHTML="";
                    }

                    var nameField = document.getElementById("name");
                    var name = document.getElementById("name").value;
                    if(name.length == 0) {
                        slanje_forme = false;
                        nameField.style.border = "1px dashed red";
                        document.getElementById("nameerror").innerHTML="Name is required!<br>";
                    }
                    else{
                        nameField.style.border = "1px solid green"; 
                        document.getElementById("nameerror").innerHTML="";
                    }

                    var surnameField = document.getElementById("surname");
                    var surname = document.getElementById("surname").value;
                    if(surname.length == 0) {
                        slanje_forme = false;
                        surnameField.style.border = "1px dashed red";
                        document.getElementById("surnameerror").innerHTML="Surname is required!<br>";
                    }
                    else{
                        surnameField.style.border = "1px solid green"; 
                        document.getElementById("surnameerror").innerHTML="";
                    }

                    var passwordField = document.getElementById("password");
                    var password = document.getElementById("password").value;
                    if(password.length == 0) {
                        slanje_forme = false;
                        passwordField.style.border = "1px dashed red";
                        document.getElementById("passworderror").innerHTML="Password is required!<br>";
                    }
                    else{
                        passwordField.style.border = "1px solid green"; 
                        document.getElementById("passworderror").innerHTML="";
                    }

                    var passwordrField = document.getElementById("passwordR");
                    var passwordr = document.getElementById("passwordR").value;
                    if(password != passwordr) {
                        slanje_forme = false;
                        passwordrField.style.border = "1px dashed red";
                        document.getElementById("passwordRerror").innerHTML="Passwords do not match!<br>";
                    }
                    else{
                        passwordrField.style.border = "1px solid green"; 
                        document.getElementById("passwordRerror").innerHTML="";
                    }

                    if (slanje_forme == false){
                        event.preventDefault();
                    } 
                }
                
            </script>

            <?php 
            if(isset($_POST['gumb'])) {
                $username = $_POST['username'];
                $name = $_POST['name'];
                $surname = $_POST['surname'];
                $password = $_POST['password'];
                $passwordhash = password_hash($password, CRYPT_BLOWFISH);

                $connection = "localhost";
                $usernameb = "root";
                $password = "";
                $base = "projekt";
                $dbc = mysqli_connect($connection, $usernameb, $password, $base) or die('Error cant connect to database');

                $query = "SELECT username FROM users";
                $result = mysqli_query($dbc, $query) or die('Query error');

                $exists = false;
                while($row = mysqli_fetch_array($result)) {
                    if($username == $row['username']) {
                        echo"Username already exists!!";
                        $exists = true;
                        break;
                    }
                }

                if($exists == false) {
                    $query = "INSERT INTO users (username, name, surname, password, power) VALUES (?, ?, ?, ?, 'user')";
                    $stmt = mysqli_stmt_init($dbc);

                    if (mysqli_stmt_prepare($stmt, $query)) {
                        mysqli_stmt_bind_param($stmt, 'ssss', $username, $name, $surname, $passwordhash);
                        mysqli_stmt_execute($stmt);
                    }
                }
                mysqli_close($dbc);
            }
            ?>
        </section>
        <footer>
            <p>Dario Šaka dsaka@tvz.hr 2022 <img src="images/menacing.png"></p> 
        </footer>
    </div>
</body>
</html>