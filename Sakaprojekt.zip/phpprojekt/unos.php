<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Form page</title>
</head>

<body class="main">
    <div>
        <header>
            <h1>Jojo's bizzare advantures <img src="images/menacing.png"></h1>
            <section class="login">
                <?php
                    error_reporting(E_ALL & ~E_NOTICE); 
                    session_start();
                    if($_SESSION['power'] == "none") {
                        echo'<form method="post" action="login.php">
                                <button type="submit" value="login">Login</button>
                            </form>
                            <form method="post" action="register.php">
                                <button type="submit" value="register">Register</button>
                            </form>';
                    }
                    else {
                        echo $_SESSION['username'];
                        if(isset($_POST['logout'])) {
                            $_SESSION['power'] = "none";
                            echo("<meta http-equiv='refresh' content='1'>");
                        }

                        echo '<form method="post"> 
                                <button type ="submit" id="logout" name="logout" value="logout">Logout</button>
                            </form>';
                        
                    }
                ?>
            </section> <br>
            <nav>
                <ul>
                <?php 
                    if($_SESSION['power'] == "none" || $_SESSION['power'] == "user") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>';
                    }
                    else if($_SESSION['power'] == "admin") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>
                        <a href="unos.php"><li>Input</li></a>
                        <a href="admin.php"><li>Administration</li></a>';
                    }
                ?>
                </ul>
            </nav>
        </header>

        <section class="input">
            <h2>INPUT NEWS:</h2>
            <form method="post" action="script.php" enctype="multipart/form-data">
                <label for="title">Title:</label> <br>
                <input type="text" name="title" id="title"> <br>
                <span id="titleerror"></span>

                <label for="desc">Description:</label> <br>
                <textarea name="desc" id="desc" cols="50" rows="10"></textarea> <br>
                <span id="descerror"></span>

                <label for="bodytext">Full text:</label> <br>
                <textarea name="bodytext" id="bodytext" cols="50" rows="20"></textarea> <br>
                <span id="texterror"></span>

                <label for="pic">Picture:</label> <br>
                <input type="file" name="pic" id="pic"> <br>
                <span id="picerror"></span>

                <label for="cat">Category:</label> <br>
                <select name="cat" id="cat">
                    <option value="" selected disabled></option>
                    <option value="Release">Release news</option>
                    <option value="Event">Event news</option>
                </select> <br>
                <span id="caterror"></span>

                <label for="archive">Archive:</label>
                <input type="checkbox" name="archive" id="archive"> <br>
                <span id="picerror"></span>

                <button type="reset" value="reset">Reset</button>
                <button type="submit" id="gumb" value="accept">Accept</button>
            </form>

            <script type="text/javascript">
                document.getElementById("gumb").onclick = function (event) {
                    var slanje_forme = true;
                    
                    var titleField = document.getElementById("title");
                    var title = document.getElementById("title").value;
                    if(title.length < 5 || title.length > 30) {
                        slanje_forme = false;
                        titleField.style.border = "1px dashed red";
                        document.getElementById("titleerror").innerHTML="Title must be between 5 and 30 characters long!<br>";
                    }
                    else{
                        titleField.style.border = "1px solid green"; 
                        document.getElementById("titleerror").innerHTML="";
                    }

                    var descField = document.getElementById("desc");
                    var desc = document.getElementById("desc").value;
                    if(desc.length < 10 || desc.length > 100) {
                        slanje_forme = false;
                        descField.style.border = "1px dashed red";
                        document.getElementById("descerror").innerHTML="Description must be between 10 and 100 characters long!<br>";
                    }
                    else{
                        descField.style.border = "1px solid green"; 
                        document.getElementById("descerror").innerHTML="";
                    }

                    var textField = document.getElementById("bodytext");
                    var text = document.getElementById("bodytext").value;
                    if(text.length == 0) {
                        slanje_forme = false;
                        textField.style.border = "1px dashed red";
                        document.getElementById("texterror").innerHTML="Text must not be empty!<br>";
                    }
                    else{
                        textField.style.border = "1px solid green"; 
                        document.getElementById("texterror").innerHTML="";
                    }

                    var picFiel = document.getElementById("pic").value;
                    var pic = document.getElementById("pic").value;
                    if(pic.length == 0) {
                        slanje_forme = false;
                        document.getElementById("picerror").innerHTML="Picture must be selected!<br>";
                    }
                    else{
                        picField.style.border = "1px solid green"; 
                        document.getElementById("picerror").innerHTML="";
                    }


                    var categoryField = document.getElementById("cat");
                    var category = document.getElementById("cat").value;
                    if(document.getElementById("cat").selectedIndex == 0) {
                        slanje_forme = false;
                        categoryField.style.border = "1px dashed red";
                        document.getElementById("caterror").innerHTML="Category must be selected!<br>";
                    }
                    else{
                        categoryField.style.border = "1px solid green"; 
                        document.getElementById("caterror").innerHTML="";
                    }


                    if (slanje_forme == false){
                        event.preventDefault();
                    } 
                }
            </script>
        </section>
        <footer>
            <p>Dario Šaka dsaka@tvz.hr 2022 <img src="images/menacing.png"></p> 
        </footer>
    </div>
</body>

</html>