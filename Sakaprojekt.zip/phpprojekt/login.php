<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Login page</title>
</head>

<body class="main">
    <div>
        <header>
            <h1>Jojo's bizzare advantures <img src="images/menacing.png"></h1>
            <section class="login">
                <?php 
                    error_reporting(E_ALL & ~E_NOTICE);
                    session_start();
                    if($_SESSION['power'] == "none") {
                        echo'<form method="post" action="login.php">
                                <button type="submit" value="login">Login</button>
                            </form>
                            <form method="post" action="register.php">
                                <button type="submit" value="register">Register</button>
                            </form>';
                    }
                    else {
                        echo $_SESSION['username'];
                        if(isset($_POST['logout'])) {
                            $_SESSION['power'] = "none";
                            echo("<meta http-equiv='refresh' content='1'>");
                        }

                        echo '<form method="post"> 
                                <button type ="submit" id="logout" name="logout" value="logout">Logout</button>
                            </form>';
                        
                    }
                ?>
                
            </section> <br>
            <nav>
                <ul>
                <?php 
                    if($_SESSION['power'] == "none" || $_SESSION['power'] == "user") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>';
                    }
                    else if($_SESSION['power'] == "admin") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>
                        <a href="unos.php"><li>Input</li></a>
                        <a href="admin.php"><li>Administration</li></a>';
                    }
                ?>
                </ul>
            </nav>
        </header>

        <section class="reg">
            <form method="post">
                <label for="username">Username:</label> <br>
                <input type="text" name="username" id="username"> <br>
                <span id="usernameerror"></span>

                <label for="password">Password:</label> <br>
                <input type="password" name="password" id="password"> <br>
                <span id="passworderror"></span>

                <button type="reset" value="reset">Reset</button>
                <button type="submit" id="gumb" name="gumb" value="accept">Accept</button>
            </form>

            <script type="text/javascript">
                document.getElementById("gumb").onclick = function (event) {
                    var slanje_forme = true;

                    var userField = document.getElementById("username");
                    var user = document.getElementById("username").value;
                    if(user.length == 0) {
                        slanje_forme = false;
                        userField.style.border = "1px dashed red";
                        document.getElementById("usernameerror").innerHTML="Username is required!<br>";
                    }
                    else{
                        userField.style.border = "1px solid green"; 
                        document.getElementById("usernameerror").innerHTML="";
                    }

                    var passwordField = document.getElementById("password");
                    var password = document.getElementById("password").value;
                    if(password.length == 0) {
                        slanje_forme = false;
                        passwordField.style.border = "1px dashed red";
                        document.getElementById("passworderror").innerHTML="Password is required!<br>";
                    }
                    else{
                        passwordField.style.border = "1px solid green"; 
                        document.getElementById("passworderror").innerHTML="";
                    }

                    if (slanje_forme == false){
                        event.preventDefault();
                    } 
                }
                
            </script>

            <?php 
            if(isset($_POST['gumb'])) {
                $username = $_POST['username'];
                $password = $_POST['password'];

                $connection = "localhost";
                $usernameb = "root";
                $passwordb = "";
                $base = "projekt";
                $dbc = mysqli_connect($connection, $usernameb, $passwordb, $base) or die('Error cant connect to database');

                $query = "SELECT username, password, power FROM users";
                $result = mysqli_query($dbc, $query) or die('Query error');

                $exists = false;
                while($row = mysqli_fetch_array($result)) {
                    $passcheck = password_verify($password, $row['password']);
                    if($username == $row['username'] && $passcheck) {
                        $exists = true;
                        break;
                    }
                }

                if($exists == true) {
                    error_reporting(E_ALL & ~E_NOTICE);
                    session_start();
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['power'] = $row['power'];
                    echo "Welcome " . $_SESSION['username'];
                    echo("<meta http-equiv='refresh' content='1'>");
                }
                else {
                    echo"Wrong username or password!";
                }
                mysqli_close($dbc);
            }
            ?>
        </section>
        <footer>
            <p>Dario Šaka dsaka@tvz.hr 2022 <img src="images/menacing.png"></p> 
        </footer>
    </div>
</body>
</html>