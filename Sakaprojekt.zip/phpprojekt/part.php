<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Part page</title>
</head>
<body class="main">
    <div>
        <header>
            <h1>Jojo's bizzare advantures <img src="images/menacing.png"></h1>
            <section class="login">
                <?php
                    error_reporting(E_ALL & ~E_NOTICE); 
                    session_start();
                    if($_SESSION['power'] == "none") {
                        echo'<form method="post" action="login.php">
                                <button type="submit" value="login">Login</button>
                            </form>
                            <form method="post" action="register.php">
                                <button type="submit" value="register">Register</button>
                            </form>';
                    }
                    else {
                        echo $_SESSION['username'];
                        if(isset($_POST['logout'])) {
                            $_SESSION['power'] = "none";
                            echo("<meta http-equiv='refresh' content='1'>");
                        }

                        echo '<form method="post"> 
                                <button type ="submit" id="logout" name="logout" value="logout">Logout</button>
                            </form>';
                        
                    }
                ?>
                
            </section> <br>
            <nav>
                <ul>
                <?php 
                    if($_SESSION['power'] == "none" || $_SESSION['power'] == "user") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>';
                    }
                    else if($_SESSION['power'] == "admin") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>
                        <a href="unos.php"><li>Input</li></a>
                        <a href="admin.php"><li>Administration</li></a>';
                    }
                ?>
                </ul>
            </nav>
        </header>
        <section class="part">
            <article>
                <?php 
                    if(isset($_POST['diamond'])) {
                        echo '<h1>DIAMOND IS UNBREAKABLE</h1>';
                        echo '<em>"There are other people in this town who have the same kind of power as I do, what a surprise!"</em><br>';
                        echo '<img class="banner" src="images/Part4banner.jpg">';
                        echo "<p>Diamond is Unbreakable (Daiyamondo wa Kudakenai), alternatively Diamond is not Crash, 
                        is the fourth part of JoJo's Bizarre Adventure, serialized in Weekly Shonen Jump from May 1992 to December 1995. 
                        Originally titled JoJo's Bizarre Adventure Part 4: Josuke Higashikata (JoJo no Kimyō na Bōken 
                        Dai Yon Bu: Higashikata Jōsuke), the part spans 174 chapters and is preceded by Stardust Crusaders. <br><br>

                        In 1999, the Arrow, manifesting latent Stand abilities, travels throughout Morioh, Japan. Meanwhile, 
                        high school student Josuke Higashikata, the illegitimate son of Joseph Joestar, seeks out the culprits of a series of 
                        homicides along with his friends and Jotaro Kujo. <br><br>
                        
                        The part received a 2016 anime adaptation by David Production and a live-action film adaptation covering the first
                        couple of chapters in 2017. <br>
                        </p>";
                        echo "
                        <h2>Plot summary:</h2>
                        <p>
                        In 1999, in the town of Morioh located in S-City, M-Prefecture, a freshman named Koichi Hirose meets a man looking for 
                        Josuke Higashikata, local high school student. Josuke, who is the illegitimate child of Joseph Joestar, soon encounters the man, 
                        who introduces himself as Jotaro Kujo. Josuke reveals that he possesses the Stand Crazy Diamond, which has the ability to return any 
                        object or living creature to a previous state (though he cannot use it on himself or revive the deceased with it). 
                        After Jotaro inadvertently insults Josuke's outdated hairstyle, the two fight, with Jotaro explaining to Josuke he is one of 
                        many Stand users and that he is searching for the Bow and Arrow, an artifact that creates Stands. Josuke and Koichi eventually 
                        come across a pair of Stand-using brothers, Okuyasu and Keicho Nijimura. Keicho, the older brother, shoots Koichi with the Arrow, 
                        which nearly kills him. When Josuke heals Koichi with Crazy Diamond, he develops a Stand, Echoes. After Keicho and Okuyasu are 
                        defeated, Keicho is killed by the Stand Red Hot Chili Pepper, which takes the Bow and Arrow. Okuyasu then joins Josuke's group 
                        to avenge his brother, encountering several other Stand users before they eventually find and defeat Akira Otoishi, Red Hot Chili 
                        Pepper's user, as Joseph arrives in Morioh. The Bow and Arrow are taken into Jotaro's custody 
                        and all seems to be over for the moment. <br><br>

                        Soon afterward, after Josuke tries spending time with Joseph, the group encounters other 
                        Stand users such as eccentric manga artist Rohan Kishibe, middle schooler Shigekiyo Shigechi Yangu, 
                        and an beautician named Aya Tsuji. Koichi and Rohan later stumble across the mysterious Ghost Alley, where 
                        they meet the ghosts of Reimi Sugimoto and her dog Arnold; They learn that Reimi and Arnold were murdered a decade 
                        ago by a serial killer who is still lurking in Morioh. The culprit is eventually revealed to be a handsome office worker 
                        named Yoshikage Kira, who seeks to satisfy his murderous urges while living a peaceful, quiet life. Kira has acquired a Stand 
                        named Killer Queen, which has the ability to turn anything it touches into a bomb. He is discovered by Shigechi, who he promptly 
                        murders, but his impulsive cover-up leads to a brief battle with Jotaro and Koichi in which Kira is injured and later cornered by 
                        Josuke and Okuyasu. Facing certain defeat, Kira uses Aya's Stand to assume the identity of a man named Kosaku Kawajiri, 
                        kills them both, and disappears. Kira's father Yoshihiro, a ghost who uses his Stand to live on in a photo,
                        uses a second Bow and Arrow to create an army of Stand users to protect his son, 
                        including a dying cat that reincarnated as a Stand-plant hybrid named Stray Cat, which shoots 
                        bubbles of compressed air at its target. <br><br>

                        Kosaku Kawajiri's son Hayato begins to suspect that his father has been replaced by an impostor 
                        and confronts Kira, who responds by impulsively murdering Hayato. While panicking that he will be 
                        discovered, Kira is pierced by Yoshihiro's Arrow a second time, giving Kira's Stand a new ability which 
                        revives Hayato. The following morning, Hayato is approached by Rohan, who is investigating whether Kira has 
                        assumed Kosaku Kawajiri's identity. After using his Stand to read Hayato's memories, Rohan is blown up by a 
                        miniature version of Killer Queen, which had been implanted into Hayato; Hayato suddenly finds himself back in 
                        bed on the same morning, one hour earlier. Kira explains that he has used Killer Queen's new ability Bites the Dust, 
                        which kills anyone who asks Hayato for Kira's identity and then rewinds time by one hour, with the victim's fate
                        assured regardless of Hayato's attempts to prevent it. The next loop ends with Josuke, Jotaro, Okuyasu, and Koichi 
                        all exploding as well; Hayato wakes up once again, and realizes that he must get Kira to deactivate Bites the Dust 
                        within an hour in order to prevent the others' deaths from becoming permanent. Hayato realizes that Killer Queen and 
                        Bites the Dust cannot be used at the same time, and takes advantage of his solitary knowledge of the time loops to wake 
                        Josuke up early and arrange for him to overhear Kira blowing his cover. Kira is forced to use Killer Queen to defend himself,
                        which cancels Bites the Dust just in time to save Josuke and his allies. <br><br>

                        Josuke, with help from Hayato and Okuyasu, engages Kira in a pitched battle. Kira combines his Stand's 
                        powers with Stray Cat to create invisible projectile bombs. Josuke and Hayato hide in a house, but Kira 
                        plants Yoshihiro's photo into Hayato's pocket, allowing him to detect Josuke's location without being able to see him. 
                        However, his trick is exposed and Josuke mimics Yoshihiro's voice, tricking Kira into detonating his own father. Meanwhile, 
                        Okuyasu separates Stray Cat from Killer Queen, disabling Kira's projectile bombs. As Jotaro, Koichi, and Rohan 
                        arrive on the scene, Kira attempts to use a nearby paramedic to activate Bites the Dust and rewind time once more, 
                        but he is stopped in the nick of time by Jotaro with assistance from Koichi. An arriving ambulance accidentally crushes 
                        Kira's head, killing him. Kira's ghost is confronted by Reimi, who causes his soul to be dragged into the underworld. Her 
                        mission accomplished, Reimi gives the group her final farewells and moves on to the afterlife. The next day, Josuke bids 
                        farewell to Jotaro and Joseph, who leave Morioh as the summer of 1999 draws to a close.
                        </p>";
                    }
                    else if(isset($_POST['gold'])) {
                        echo '<h1>VENTO AUREO</h1>';
                        echo "<em>I'm planning on defeating your boss and taking over this city... In order to get rid of the gangsters that sell drugs to 
                        children... you have to become a gang member yourself.</em>";
                        echo '<img class="banner" src="images/Part5banner.jpg">';
                        echo "<p>
                        Vento Aureo (Ōugon no Kaze), translated into English as Golden Wind, is the fifth part of JoJo's Bizarre Adventure, 
                        serialized in Weekly Shonen Jump from December 1995 to April 1999. Originally titled JoJo's Bizarre Adventure Part 5 
                        Giorno Giovanna: Golden Heritage (JoJo no Kimyō na Bōken Dai Go Bu Joruno Jobāna [Ōgon naru Isan]), the part spans a 
                        total of 155 chapters and takes place after Diamond is Unbreakable. <br><br>

                        Set in 2001 Italy, the story follows Giorno Giovanna and his dream to rise within the Neapolitan mafia and defeat 
                        the boss of Passione, the most powerful and influential gang, in order to become a Gang-Star. With the aid of a capo 
                        and his men, and fueled by his own resolve, Giorno sets out to fulfill his goal of absolving the mafia of its corruption. <br><br>

                        The part received a 2018 anime adaptation by David Production. It was also adapted into an action-adventure 
                        video game by Capcom in 2002.
                        </p>";
                        echo "
                        <h2>Plot summary:</h2>
                        <p> 
                        In 2001, Koichi Hirose arrives in Naples, Italy at Jotaro Kujo's request to obtain a skin sample from a young man named Haruno 
                        Shiobana whom Jotaro suspects to be the son of Dio Brando, conceived with Jonathan Joestar's body prior to the events of 
                        Stardust Crusaders. Koichi ends up being scammed by Haruno, now going by the name of Giorno Giovanna, whose Stand 
                        Gold Experience allows him to transform inanimate objects into living organisms. After defeating a Stand-wielding mafioso 
                        named Bruno Bucciarati who was sent to avenge the injury he inflicted on a gang member, Giorno wins him over by revealing 
                        his goal of becoming a mafia boss to better Naples and end the scourge of drug trafficking plaguing the city's youth. 
                        Bucciarati agrees to introduce Giorno into the Passione organization, allowing Giorno to take a deadly initiation test 
                        from the morbidly obese capo Polpo. After convincing Koichi to cease his investigation, Giorno passes the test, though he 
                        indirectly kills Polpo afterward as revenge for an innocent bystander's death. <br><br>

                        Giorno is placed in Bucciarati's group, which consists of fellow Stand users Guido Mista, Leone Abbacchio, Narancia Ghirga 
                        and Pannacotta Fugo. Polpo's apparent suicide provides an opening for Bucciarati to achieve the rank of capo by donating Polpo's 
                        amassed fortune on the island of Capri to a gang representative. Bucciarati is then given Polpo's final mission: Passione's boss, 
                        a mysterious figure whose identity is unknown to even his subordinates, requests that his teenage daughter Trish Una be brought 
                        safely to him in Venice. Along the way, Bucciarati's team eliminates all but one of the members of Passione's traitorous Hitman 
                        Team, who seek to use Trish as a means to identify and defeat the boss. On the boss's orders, the group retrieves a key in Pompeii 
                        and use it to unlock the room inside the Stand-using turtle Coco Jumbo. <br><br>

                        After reaching Venice safely and escorting Trish into the Church of San Giorgio Maggiore, 
                        Bucciarati realizes that the boss intends to kill his own daughter to maintain his anonymity. 
                        An enraged Bucciarati pursues the boss in order to save Trish, but suffers grievous injuries at the hands of the boss's 
                        invincible Stand King Crimson, which has the ability to see into and skip time's progression several seconds into the future. 
                        Giorno seemingly heals Bucciarati's injuries as he escapes with Trish, and the two manage to escape the church, unaware that the 
                        body Bucciarati's soul resides in has already died. Despite Fugo's objections, the rest of the group defects from Passione and 
                        pledges to uncover the boss's identity in order to defeat him. The group and Trish, who discovers her own Stand Spice Girl, are 
                        forced to fight for their lives against elite assassins sent by the boss. <br><br>

                        Bucciarati's group travels to the island of Sardinia after Trish recalls it as the boss's birthplace so Abbacchio can use 
                        his Stand to identify the boss. Vinegar Doppio, an alter ego of the boss who acts as his liaison to the assassins, reaches 
                        Sardina at the same time as the Hitman Team's leader, killing him before getting close enough for the boss to quickly kill Abbacchio. 
                        But Abbacchio creates a likeness of the boss in his final moments before the group are then contacted by a third party, who 
                        reveals the boss's name to be Diavolo and requests that the group visit the Colosseum in Rome to receive a special Arrow. 
                        The group arrives in Rome, but is held up when they meet a pair of Stand users called Cioccolatta and Secco, assigned to bump 
                        off Buccciarati's group. The group manages to overpower the enemy Stand users, but Diavolo reaches the informant first. 
                        He confronts the informant, who is revealed to be Jean Pierre Polnareff. Diavolo fatally wounds Polnareff, forcing him to 
                        stab his Stand Silver Chariot with the Arrow and evolve it into Chariot Requiem. Requiem, gifted the ability to swap the souls 
                        of living beings, goes berserk and causes a city-wide soul swap, leaving Polnareff's soul in Coco Jumbo's body. <br><br>

                        Polnareff explains the Arrow and his Stand to the group, who realize that their own Stands will attack them upon approaching the 
                        Arrow. Though the group cripples Bucciarati's body as it awakens, Narancia is killed in skipped time, revealing a dying Doppio 
                        to be a separate soul of Diavolo's. Giorno attempts to revive Narancia, but can only reclaim his own body that was originally swapped. 
                        Diavolo's own soul is revealed to be inside Mista's body alongside Trish's soul and succeeds in weakening Requiem, but Bucciarati 
                        sacrifices himself to dispel the soul swap and pass the Arrow to Giorno. Using the Arrow, Giorno evolves his Stand into Gold 
                        Experience Requiem, which condemns Diavolo to an endless loop of being killed in various ways. <br><br>

                        The story jumps back to an incident before Bucciarati's encounter with Giorno. Visited by a florist requesting 
                        vengeance for his daughter's death, Bucciarati, Fugo, and Mista visit the alleged murderer's place of residence. 
                        It is revealed that the suspect, Scolippi, is a Stand user whose Stand tries to euthanize those who are fated to die, 
                        such as the florist's daughter. Scolippi's Stand predicts Bucciarati's death and attempts to reach him, but Mista breaks 
                        the Stand before it can do so. As the group leaves the building, the dust of the broken Stand forms the shapes of Bucciarati's, 
                        Narancia's, and Abbacchio's faces, revealing their changed fates to an optimistic Scolippi. <br><br>

                        As Trish and Mista return to the Colosseum, unaware of Bucciarati's death, Giorno and Polnareff's ghost 
                        (now within Coco Jumbo's Stand) agree to preserve the Arrow. Sometime afterward, Giorno becomes the new boss of Passione as 
                        Mista and Polnareff observe gang members kneeling before him.
                        </p>
                        ";
                    }
                    else if(isset($_POST['stone'])) {
                        echo '<h1>STONE OCEAN</h1>';
                        echo '<em>"There might be a way... to go to Heaven."</em>';
                        echo '<img class="banner" src="images/Part6banner.png">';
                        echo "<p>
                        Stone Ocean (Sutōn Ōshan) is the sixth part of JoJo's Bizarre Adventure, serialized in 
                        Weekly Shonen Jump from December 7, 1999 to April 8, 2003. Originally titled JoJo's Bizarre Adventure Part 6 
                        Jolyne Cujoh: Stone Ocean (JoJo no Kimyō na Bōken Dai Roku Bu Kūjō Jorīn - Sutōn Ōshan), 
                        the part spans 158 chapters and is preceded by Vento Aureo. <br><br>

                        Set in 2011, Florida, Jolyne Cujoh, daughter of Jotaro, is wrongfully accused of a crime she didn't 
                        commit and sent to a maximum security prison. While imprisoned, she struggles within a longstanding plot 
                        agreed between dead villain DIO and ideologue Enrico Pucci. <br><br>

                        Stone Ocean is the last part set in the original timeline of JoJo - from Steel Ball Run onwards, the 
                        story takes place in an entirely separate continuity. <br><br>

                        The part received a 2021 anime adaptation by David Production, which has been announced on April 4, 
                        2021 and began airing worldwide on Netflix on December 1, 2021.
                        </p>";
                        echo "
                        <h2>Plot summary:</h2>
                        <p>
                        Set near Port St. Lucie, Florida in 2011, the story follows Jotaro Kujo's estranged daughter Jolyne Cujoh, 
                        who was set up by her ex-boyfriend Romeo Jisso to serve a 15-year sentence at Green Dolphin Street Prison. 
                        Prior to her incarceration, Jolyne is stabbed by a pendant that belonged to her father and contains a fragment 
                        of the Stand-bestowing Arrow. Jolyne manifests her Stand before being visited by Jotaro, who attempts to break 
                        his daughter out while revealing that she was framed by a disciple of Dio who seeks to kill her. But Jotaro realizes 
                        too late that he was lured into a trap as he ends up in a coma when his Stand and memories are extracted as discs by a 
                        Stand named Whitesnake. Jolyne realizes the extent of her father's love for her and resolves to recover the discs from 
                        Whitesnake's user, a Catholic priest known as Enrico Pucci who met Dio in the 80s. Along the way, Jolyne gains allies 
                        in Emporio Alnino, a boy born in prison; Ermes Costello, an inmate seeking to avenge her sister. Jolyne also fights and 
                        befriends Foo Fighters, a plankton colony Pucci gave sentience to guard the stolen Stand Discs and inhabits a female 
                        prisoner's corpse. While Jolyne recovers Star Platinum, Enrico holds on to Jotaro's memories which hold knowledge of 
                        Dio's plan to establish a perfect world when certain conditions are met at a predestined place on the night of the new moon. <br><br>

                        As Jolyne's group are joined by Narciso Anasui, an inmate who fell in unrequited love for Jolyne; 
                        and an amnesic named Weather Report, Pucci begins sacrificing prisoners to instill life into one of 
                        Dio's bones in the form of a green homunculus called the Green Baby that Pucci absorbs. Foo Fighters 
                        and Anasui are mortally wounded in the attempt to stop Pucci, with Foo Fighters uses the last of her 
                        strength to save Anasui's life and retrieve Jotaro's memory Disc. Jolyne and her allies escape from prison, 
                        and Jolyne sends both of Jotaro's Discs to the Speedwagon Foundation. <br><br>

                        Weather Report retrieves his memory Disc, causing him to remember his past as Wes Bluemarine, Pucci's long lost twin brother. 
                        It is revealed that in the past, their younger sister's suicide awakened their Stand abilities and acted as the genesis of 
                        Pucci's ideology that humans would be happier having full knowledge of their fate. Weather, regaining his ability to use 
                        Heavy Weather, dies confronting Pucci and uses Whitesnake's ability to leave his Stand's Disc for his allies. 
                        Pucci reaches Cape Canaveral as Whitesnake evolves into the gravity-manipulating C-Moon, overpowering Jolyne's 
                        group as Jotaro arrives. But Pucci realizes that he can use C-Moon to replicate the new moon's gravity, allowing 
                        him to complete his plan two days early. Pucci evolves his Stand into the time-accelerating Made in Heaven, using 
                        it to rapidly advance time. Despite Anasui's self-sacrifice, Pucci kills Ermes and Jotaro, and Jolyne sacrifices 
                        herself to save Emporio. <br><br>

                        Pucci manages to accelerate time to the end of the universe, leading to a new cycle of time and a parallel 
                        universe where all surviving humans have subconscious precognition of their lives and the Joestar bloodline no 
                        longer exists. Pucci then attempts to kill Emporio, only to inadvertently insert Weather Report's Stand Disc 
                        into the child's head. Pucci attempts to accelerate time once more, but Emporio uses Weather Report to increase 
                        the surrounding oxygen's concentration to a lethal amount. A poisoned and paralyzed Pucci pleads with Emporio to 
                        spare him long enough to make his new universe permanent, but Emporio is unmoved, and Weather Report caves in Pucci's
                        skull by smashing his head into a piano and into the floor. <br><br>

                        With Pucci's premature death, the parallel universe collapses with a new universe established where Pucci no longer 
                        exists and the precognitive effects of the second universe are gone. In the new universe, with Foo Fighters not among them, 
                        Emporio encounters alternate versions of his deceased friends with Irene, Jolyne's counterpart, engaged to Anakiss, Anasui's 
                        counterpart. As Ermes's and Weather Report's counterparts join the two as hitchhikers, Emporio tearfully re-introduces himself 
                        to Irene after noticing her star-shaped birthmark as the group drive off to meet Irene's father, Jotaro's unseen counterpart.
                        </p>
                        ";
                    }
                    else if(isset($_POST['tusk'])) {
                        echo '<h1>STEEL BALL RUN</h1>';
                        echo '<em>"This story is the tale of me starting to walk. Not in the physical sense... but in an adolescence to 
                        adulthood sort of way..."</em>';
                        echo '<img class="banner" src="images/Part7banner.png">';
                        echo "<p>
                        Steel Ball Run (Sutīru Bōru Ran) is the seventh part of the JoJo's Bizarre Adventure series. 
                        Initially serialized in Weekly Shonen Jump from January 19, 2004 to October 18, 2004, the part's publication later 
                        moved to Ultra Jump, where it was serialized from March 19, 2005 to April 19, 2011. <br><br>

                        Set in the U.S. in 1890, the story follows Johnny Joestar, a paraplegic ex-jockey, and Gyro Zeppeli, 
                        master in the mystic art of the Spin, as the two compete in the trans-American Steel Ball Run race and uncover its 
                        benefactor's sinister motivations. <br><br>

                        Steel Ball Run marks the start of a new universe entirely divorced from the events of Parts 1-6. 
                        Despite this, the story retains several core features of JoJo, including Stands, as well as numerous 
                        references to the original continuity.
                        </p>";
                        echo "
                        <h2>Plot summary:</h2>
                        <p>
                        In an alternate 1890, racing jockeys from all over the world flock to the United States to take part in the Steel Ball Run a 
                        cross-country horse race from San Diego to New York City with a fifty million dollar prize. A paraplegic named Johnny Joestar 
                        enters the race to learn the mysterious Spin ability of a former Neapolitan executioner named Gyro Zeppeli, who temporarily 
                        restored Johnny's mobility. While beginning as rivals, Johnny and Gyro become friends as they travel through the wilderness 
                        while fending off various assassins, terrorists, outlaws and other violent competitors. Although the Steel Ball Run is organized 
                        by the eccentric oil tycoon Stephen Steel, it is backed by the United States government with president Funny Valentine using the 
                        race as a front to collect the scattered pieces of a 1900-year-old corpse known as the Saint's Corpse (heavily implied to be the 
                        body of Jesus Christ), to reassemble the body and gain power, with the Corpse's heart currently in his possession. <br><br>

                        After Johnny and Gyro encounter another piece of the Saint's Corpse, it is absorbed into Johnny's body and he develops the 
                        evolving Stand Tusk, allowing him to fend off one of Valentine's subordinates. Later, they meet the mysterious racer Diego 
                        Brando who obtains one of two Corpse eyes, while Gyro gains the other. Johnny and Gyro continue the race, encountering other 
                        racers, gaining and losing Corpse parts and enhancing their Spin techniques along the way. <br><br>

                        Meanwhile, Stephen's wife Lucy tries to uncover and foil Valentine's plan with later assistance from another racer, Hot Pants. 
                        However, Valentine discovers Lucy and takes her captive after she fuses with the Corpse and seemingly becomes pregnant with the 
                        Corpse's head. Diego and Hot Pants ally against and fight Valentine on a moving train, but are overpowered and killed by the 
                        president and his Stand “D4C” (Dirty Deeds Done Dirt Cheap) though Valentine is forced to transfer his soul into an alternate 
                        universe's Valentine to survive the fight. Lucy begins to metamorphose, enhancing Valentine's stand with a new misfortune-redirecting 
                        ability “Love Train”. Johnny and Gyro arrive and attempt to battle the seemingly invulnerable Valentine, only for Valentine 
                        to overpower them both and kill Gyro. Mourning his mentor and friend, Johnny achieves the earlier-taught Golden Spin, 
                        enhances his Stand and overwhelms Valentine. Valentine attempts to fake his surrender, but Johnny kills him, 
                        avenging his companion. <br><br>

                        The Holy Corpse separates from Lucy, only to be stolen by an unknown antagonist. Pursuing the thief into the final stage of the 
                        Steel Ball Run, Johnny is shocked to find that it is a megalomaniacal version of Diego Brando, taken from a different universe 
                        by Valentine, entrusted with the Corpse and armed with the time-stopping Stand THE WORLD. Johnny attempts to engage the 
                        Alternate Diego, but Diego defeats him with his own attack and clinches first place in the race. He brings the Corpse to 
                        Trinity Church, only to run into Lucy armed with the severed head of the root world's Diego and die once he comes into 
                        contact with said head. <br><br>

                        As the race ends, first place is awarded to the carefree Pocoloco, who had slept through 
                        the start of the race and only caught up by sheer luck, while Stephen Steel arrives to save Johnny. 
                        Valentine's death is covered up as retirement from public life, with concerns over the race placated by the donation 
                        of the prize money to charitable causes. Johnny, having regained his ability to walk through the power of his Stand and the 
                        Spin, leaves America to return Gyro's body to his family. On the boat, he meets the Japanese runner-up racer Norisuke Higashikata. 
                        Johnny later marries Norisuke's daughter Rina, leading to the events of Part 8, JoJolion.
                        </p>
                        ";
                    }
                    else if(isset($_POST['bubble'])) {
                        echo '<h1>JOJOLION</h1>';
                        echo '<em>"This is a story about breaking a curse... This mysterious boy buried in the ground, who in the world is he?"</em>';
                        echo '<img class="banner" src="images/Part8banner.jpg">';
                        echo "<p> 
                        JoJolion (JoJorion) is the award-winning eighth part of JoJo's Bizarre Adventure, serialized in Ultra Jump from May 19, 
                        2011 to August 19, 2021. <br><br>

                        The story begins in 2011 and follows Josuke Higashikata, a young man afflicted by retrograde amnesia, 
                        in his search to uncover his identity in Morioh Town, a coastal Japanese town affected by the Tohoku earthquake. 
                        However, his digging pulls him and his adoptive family into the unfinished business between his previous life and an 
                        impending inhuman threat. <br><br>

                        JoJolion represents the second part of the series set in the Steel Ball Run continuity. 
                        The part also won the Grand Prize for manga at the 2013 Japan Media Arts Festival. In 2021, Araki won the 
                        Iwate Hometown Special Manga Award for Part 8 and his contributions to the prefecture.
                        </p>";
                        echo "
                        <h2>Plot summary:</h2>
                        <p>
                        Set in the same continuity as Steel Ball Run, S-City, M-Prefecture (Emu-ken, Esu-shi) was devastated by the 2011 Tōhoku 
                        earthquake and tsunami. In the aftermath, strange structures known colloquially as the Wall Eyes (Kabe no Me) 
                        appear all over the town of Morioh (Moriō-chō), with the ground beneath them having the strange property
                        of swapping traits of whatever two objects are buried there. <br><br>

                        A local college student named Yasuho Hirose finds a mysterious youth buried under one of the Wall Eyes, 
                        and they set off on an adventure together to try to recover his identity. Yasuho conducts her investigation while 
                        leaving the youth under the care of her childhood friend's father Norisuke Higashikata IV, who names him Josuke. 
                        As Yasuho finds Yoshikage's hospitalized mother Holy Joestar-Kira, who suffers from a form of dementia, 
                        Josuke finds Kira's sibling Kei Nijimura, who explains that he is a fusion of Kira and someone else. <br><br>

                        When Josuke later confronts Norisuke over his reasons for taking him in, he learns that the Higashikata family needs 
                        Yoshikage's memories to end a family curse that is gradually petrifying them. The solution is explained to be a fruit 
                        called Locacaca, which cures a person of any ailment while taking a part of them in exchange. Jobin Higashikata, 
                        Norisuke's oldest son, has been using the family fruit parlor to smuggle Locacaca trees into the country in 
                        cooperation with a group of mysterious stone-based beings called Rock Humans. <br><br>

                        Jobin and the Rock Humans begin targeting Josuke and Yasuho as the former learns of his other former identity, 
                        Josefumi Kujo. Prior to Josuke's discovery, Kira and Josefumi had stolen a branch growing a new type of Locacaca 
                        fruit, which uses another person as collateral for the exchange. After Kira was fatally injured by the Rock Humans, 
                        he and Josefumi grafted and used the new Locacaca in the Higashikatas' orchard; the two of them fell into the ground 
                        as the Tōhoku earthquake struck, being buried beneath the future Wall Eyes. Coping with the revelation that he is a 
                        fusion of Josefumi and Kira, Josuke resolves to retrieve the Locacaca fruit and cure Holy; Jobin learns of the fruit 
                        and plots to cure Tsurugi with it. <br><br>

                        At Norisuke's behest, Josuke meets with a plant appraiser named Rai Mamezuku, whom he leads to the Higashikata 
                        orchard to identify the branch. Jobin's alliance with the Rock Humans falters when a Rock Human named Poor Tom 
                        attacks the orchard, forcing Jobin to set it ablaze to protect both his family and the branch. Poor Tom's allies 
                        arrive in an ambulance, but Poor Tom is killed by an unseen force as he approaches them. The two Rock Humans inside 
                        the ambulance seemingly take the new Locacaca branch, unaware that Tsurugi has misled them with his Stand; in reality, 
                        the branch is in Jobin's possession. By chance, Yasuho soon encounters and defeats one of the Rock Humans, Wu Tomoki, 
                        at the hospital. Wu reveals his hospital's involvement in Locacaca research before Josuke and Mamezuku arrive and finish him. 
                        Finding no clue as to the branch's whereabouts, the three plan to hunt down the hospital's head doctor. <br><br>

                        The group encounters an intern at the hospital named Tooru, who is revealed to be Yasuho's ex-boyfriend. 
                        Tooru points the group in the direction of the head doctor, Satoru Akefu; while attempting to pursue him, the group is 
                        attacked by Akefu's powerful calamity-based Stand, Wonder of U, and are forced to retreat after a bystander is killed. 
                        While hiding from the police, Josuke and Mamezuku are again attacked by Wonder of U, leading them to realize that the Stand is 
                        triggered by the intent to pursue. Mamezuku is arrested, but Josuke deliberately injures himself so that he can be 
                        taken to the hospital. Vowing once more to save his mother, Josuke decides to make the head doctor pursue him. <br><br>

                        Akefu learns of Josuke's plot, the latter having realized that Holy was experimented upon. Mamezuku, having escaped from prison, 
                        realizes that Satoru Akefu is the Stand itself as the two simultaneously pursue Josuke. Mamezuku attacks Akefu, but is fatally 
                        wounded by the trap Josuke had set for him. As he dies, Mamezuku reveals the latent Spin within Josuke's ability. Meanwhile, 
                        Yasuho pursues her suspicion that the branch is with the Higashikatas, eventually revealing the branch to the family on accident. 
                        Norisuke confronts Jobin, who incapacitates him; Jobin himself is killed shortly afterward by the force of calamity. 
                        As Tooru arrives at the Higashikata estate, Yasuho realizes his true identity as the Stand user of Wonder of U. <br><br>

                        Despite Tooru's warnings that contacting her allies will put her in calamity's line of fire, Yasuho calls Josuke and informs 
                        him of her findings. Though Akefu escapes Josuke's attack, Josuke and Yasuho combine their abilities with Josuke's Spin to 
                        attack Tooru with a transient bubble. A gravely-wounded Tooru eats one of the new Locacaca fruits and attempts to initiate an 
                        exchange, only to be pinned to the ground by Jobin's mother, Kaato Higashikata. Kaato forces Tooru to exchange with Tsurugi and 
                        receive his curse, killing both Tooru and herself and destroying the last of the new Locacaca branch in the process. <br><br>

                        The story jumps back to 1941, as an elderly Lucy Steel arrives in Morioh to investigate the Locacaca fruit on behalf of the 
                        Speedwagon Foundation. At the train station, she meets a youth named Fumi who is also visiting Morioh. The two drive to the 
                        Higashikata estate, but are attacked by a nearby guard rail; Lucy narrowly escapes after Josefumi attacks the rail with his 
                        Stand. As the two escape, Fumi reveals himself to be Joseph Joestar (Fumi is part of the name 'Josefumi' which is a 
                        Japanization of 'Joseph'), Johnny Joestar's grandson and Holy Joestar-Kira's father. <br><br>

                        As the Higashikata family mourns their loss, Yasuho sees a glimmer of hope in Tsurugi's eyes as ambulances arrive on the scene. 
                        Josuke reunites with Yasuho, and the two visit Holy in the hospital. Though Yasuho spots Josefumi Kujo's mother, 
                        Josuke decides not to go after her, as he has accepted being neither Josefumi nor Kira. 
                        The two meet with the Higashikata family once more at a cake shop, as the family tries to decide on a cake to celebrate 
                        Norisuke's release from the hospital. The family eventually decides to leave the decision up to Josuke; Yasuho takes her 
                        leave, satisfied that Josuke has found a loving family.
                        </p>";

                    }
                ?>
            </article>
        </section>

        <footer>
            <p>Dario Šaka dsaka@tvz.hr 2022 <img src="images/menacing.png"></p> 
        </footer>
    </div>
</body>
</html>