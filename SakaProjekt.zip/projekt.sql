-- MariaDB dump 10.19  Distrib 10.4.24-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: projekt
-- ------------------------------------------------------
-- Server version	10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `archive` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (19,'Volume 27 release','Volume27.jpg','News following release of volume 27 of Jojolion.','When All Curses Are Broken (全ての呪いが解けるとき Subete no Noroi ga Tokeru Toki) is the twenty-seventh and final volume of JoJolion and the one-hundred thirty first volume of the JoJo\'s Bizarre Adventure manga. It covers the Go Beyond story arc and The Radio Gaga Incident story arc.\r\nChapters: 107-110 (954-957).\r\nDate Released: September 17, 2021.\r\n','Release',0),(20,'Volume 26 release','Volume26.jpg','Jojolion volume 26 release information','Go Beyond (ゴー・ビヨンド Gō Biyondo) is the twenty-sixth volume of JoJolion and the one-hundred thirtieth volume of the JoJo\'s Bizarre Adventure manga. It covers the end of The Wonder of You story arc and the beginning of the Go Beyond story arc.\r\nChapters: 103-106 (950-953).\r\nDate Released: May 19, 2021.','Release',0),(21,'Volume 25 release','Volume25.jpg','News concerning the Jojolion volume 25 release.','The Ultimate Dilemma (究極のジレンマ Kyūkyoku no Jirenma) is the twenty-fifth volume of JoJolion and the one-hundred twenty-ninth volume of the JoJo\'s Bizarre Adventure manga. It covers more of The Wonder of You story arc.\r\nChapters: 99-102 (946-949).\r\nDate Released: December 18, 2020.\r\n','Release',0),(22,'Volume 24 release','Volume24.jpg','News following release of volume 24 of Jojolion.\r\n','Just Don\'t Move (動かないしかない Ugokanai Shikanai, lit. Nothing But Not Moving) is the twenty-fourth volume of JoJolion and the one-hundred twenty-eighth volume of the JoJo\'s Bizarre Adventure manga. It covers more of The Wonder of You story arc.\r\nChapters: 95-98 (942-945).\r\nDate Released: October 16, 2020.','Release',0),(29,'Netflix Anime Event','NetflixEvent.jpg','Netflix Japan anime event announced','Netflix announced a Netflix Japan Anime event will be held online on March 26-27, 2022. The idea will be to offer people a chance to learn more about ongoing and new series. In each case, people involved with the series appear. For example, voice actors for major characters will show up to talk about their roles. Among the Netflix titles that will appear during this latest series of streams will be JoJo’s Bizarre Adventure: Stone Ocean, Tiger & Bunny 2, Spriggan, and Ultraman.\r\nHere’s the full schedule of what will appear and when during the Netflix Japan anime event.\r\n<img src=\'https://pbs.twimg.com/media/FM5opwIVgAAbCtC?format=jpg&name=large\' style=\'max-width: 100%\'>\r\nAll of the shows are ones with more on the way or that are just about to appear. For example, only the first 12 episodes of JoJo’s Bizarre Adventure are available on Netflix right now. More are on the way. Thermae Romae Novae will show up on March 28, 2022. Tiger & Bunny 2 has an April 8, 2022 release date. Spriggan will show up in 2022.','Event',0);
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `power` varchar(35) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'admin','dario','saka','$2y$10$jWiE7EEVyu1J/xhd9cG/SegrqpHRgX6c/o8y6QKOvbOhQ1Kr8zOPW','admin'),(3,'user','first','test','$2y$10$xD.IXGsYta8BDl6iQiT1TeHCHj.F1ifK7KuTpuUHX7imEJPTpKHhi','user');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-18 17:02:22
