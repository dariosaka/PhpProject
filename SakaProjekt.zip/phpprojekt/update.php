<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Prewiev page</title>
</head>

<body class="main">
    <div>
        <header>
            <h1>Jojo's bizzare advantures <img src="images/menacing.png"></h1>
            <section class="login">
                <?php
                    error_reporting(E_ALL & ~E_NOTICE); 
                    session_start();
                    if($_SESSION['power'] == "none") {
                        echo'<form method="post" action="login.php">
                                <button type="submit" value="login">Login</button>
                            </form>
                            <form method="post" action="register.php">
                                <button type="submit" value="register">Register</button>
                            </form>';
                    }
                    else {
                        echo $_SESSION['username'];
                        if(isset($_POST['logout'])) {
                            $_SESSION['power'] = "none";
                            echo("<meta http-equiv='refresh' content='1'>");
                        }

                        echo '<form method="post"> 
                                <button type ="submit" id="logout" name="logout" value="logout">Logout</button>
                            </form>';
                        
                    }
                ?>
                
            </section> <br>
            <nav>
                <ul>
                <?php 
                    if($_SESSION['power'] == "none" || $_SESSION['power'] == "user") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>';
                    }
                    else if($_SESSION['power'] == "admin") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>
                        <a href="unos.php"><li>Input</li></a>
                        <a href="admin.php"><li>Administration</li></a>';
                    }
                ?>
                </ul>
            </nav>
        </header>
        <article>
            <?php
            session_start();
            $connection = "localhost";
            $username = "root";
            $password = "";
            $base = "projekt";
            $dbc = mysqli_connect($connection, $username, $password, $base) or die('Error cant connect to database');

            $query = "SELECT * FROM news";
            $result = mysqli_query($dbc, $query) or die('Query error');

            if ($result) {
                while ($row = mysqli_fetch_array($result)) {
                    if ($_SESSION['idUpdate'] == $row['id']) {
                        $titleDef = $row['title'];
                        $dscDef = $row['description'];
                        $txtDef = $row['text'];
                        $categoryDef = $row['category'];
                        $archiveDef = $row['archive'];
                        $imageDef = $row['image'];
                        break;
                    }
                }
            }

            echo "New post preview (id=" . $_SESSION['idUpdate'] . "):";
            $id = $_SESSION['idUpdate'];

            if ($_POST['title'] == "") {
                echo "<h1>$titleDef</h1><br>";
            } else {
                $title = $_POST['title'];
                $title = str_replace("'", "''", $title);
                echo "<h1>$title</h1><br>";

                $query = "UPDATE news SET title = ? WHERE id = '$id'";
                
                $stmt = mysqli_stmt_init($dbc);

                if (mysqli_stmt_prepare($stmt, $query)) {
                    mysqli_stmt_bind_param($stmt, 's', $title);
                    mysqli_stmt_execute($stmt);
                }
            }

            if ($_POST['desc'] == "") {
                echo "<p>$dscDef</p><br>";
            } else {
                $dsc = $_POST['desc'];
                $dsc = str_replace("'", "''", $dsc);
                echo "<p>$dsc</p><br>";

                $query = "UPDATE news SET description = ? WHERE id = '$id'";
                $stmt = mysqli_stmt_init($dbc);

                if (mysqli_stmt_prepare($stmt, $query)) {
                    mysqli_stmt_bind_param($stmt, 's', $dsc);
                    mysqli_stmt_execute($stmt);
                }
            }


            if (is_uploaded_file($_FILES['pic']['tmp_name'])) {
                $pic = $_FILES['pic']['name'];
                $target_dir = "images/";
                $target_file = $target_dir . basename($pic);
                move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file);

                $path = "images/$imageDef";
                unlink($path);

                echo "<img src='images/" . $pic . "'/>";

                $query = "UPDATE news SET image = ? WHERE id = '$id'";
                $stmt = mysqli_stmt_init($dbc);

                if (mysqli_stmt_prepare($stmt, $query)) {
                    mysqli_stmt_bind_param($stmt, 's', $pic);
                    mysqli_stmt_execute($stmt);
                }
            } 
            else {
                echo "<img src='images/" . $imageDef . "'/>";
            }

            if ($_POST['bodytext'] == "") {
                echo "<p>$txtDef</p><br>";
            } else {
                $txt = $_POST['bodytext'];
                $txt = str_replace("'", "''", $txt);
                echo "<p>$txt</p><br>";

                $query = "UPDATE news SET text = ? WHERE id = '$id'";
                $stmt = mysqli_stmt_init($dbc);

                if (mysqli_stmt_prepare($stmt, $query)) {
                    mysqli_stmt_bind_param($stmt, 's', $txt);
                    mysqli_stmt_execute($stmt);
                }
            }

            if (!isset($_POST['cat'])) {
                echo "<p>Category: $categoryDef</p><br>";
            } else {
                $cat = $_POST['cat'];
                echo "<p>Category: $cat</p><br>";

                $query = "UPDATE news SET category = ? WHERE id = '$id'";
                $stmt = mysqli_stmt_init($dbc);

                if (mysqli_stmt_prepare($stmt, $query)) {
                    mysqli_stmt_bind_param($stmt, 's', $cat);
                    mysqli_stmt_execute($stmt);
                }
            }

            if (!isset($_POST['archive'])) {
                echo "<p>Archiving: $archiveDef</p><br>";
            } else {
                if($_POST['archive'] == "Archive") {
                    $arc = 1;
                }
                else {
                    $arc = 0;
                }
                echo "<p>Archiving: $arc</p><br>";

                $query = "UPDATE news SET archive = '$arc' WHERE id = '$id'";
                $result = mysqli_query($dbc, $query) or die('Query error');
            }

            mysqli_close($dbc);
            ?>
        </article>

        <footer>
            <p>Dario Šaka dsaka@tvz.hr 2022 <img src="images/menacing.png"></p> 
        </footer>
    </div>
</body>

</html>