<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Admin page</title>
</head>

<body class="main">
    <div>
        <header>
            <h1>Jojo's bizzare advantures <img src="images/menacing.png"></h1>
            <section class="login">
                <?php 
                    error_reporting(E_ALL & ~E_NOTICE);
                    session_start();
                    if($_SESSION['power'] == "none") {
                        echo'<form method="post" action="login.php">
                                <button type="submit" value="login">Login</button>
                            </form>
                            <form method="post" action="register.php">
                                <button type="submit" value="register">Register</button>
                            </form>';
                    }
                    else {
                        echo $_SESSION['username'];
                        if(isset($_POST['logout'])) {
                            $_SESSION['power'] = "none";
                            echo("<meta http-equiv='refresh' content='1'>");
                        }

                        echo '<form method="post"> 
                                <button type ="submit" id="logout" name="logout" value="logout">Logout</button>
                            </form>';
                        
                    }
                ?>
                
            </section> <br>
            <nav>
                <ul>
                <?php 
                    if($_SESSION['power'] == "none" || $_SESSION['power'] == "user") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>';
                    }
                    else if($_SESSION['power'] == "admin") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>
                        <a href="unos.php"><li>Input</li></a>
                        <a href="admin.php"><li>Administration</li></a>';
                    }
                ?>
                </ul>
            </nav>
        </header>
        <section class="admin">
            
            <p>News list:</p>
            <table border="1" cellpadding="3px" style="border-collapse: collapse;">
                <tr>
                    <td>ID</td>
                    <td>Title</td>
                    <td>Description</td>
                    <td>Category</td>
                    <td>Archive</td>
                </tr>
                <?php
                $connection = "localhost";
                $username = "root";
                $password = "";
                $base = "projekt";
                $dbc = mysqli_connect($connection, $username, $password, $base) or die('Error cant connect to database');

                $query = "SELECT * FROM news";
                $result = mysqli_query($dbc, $query) or die('Query error');
                if ($result) {
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['title'] . "</td>";
                        echo "<td>" . $row['description'] . "</td>";
                        echo "<td>" . $row['category'] . "</td>";
                        echo "<td>" . $row['archive'] . "</td>";
                        echo "</tr>";
                    }
                }
                mysqli_close($dbc);
                ?>
            </table> <br>

            <form method="post">
                <label for="choice">Choose id of the row to edit/delete:</label>
                <input type="number" name="choice" id="choice">
                <select name="action" id="action">
                    <option value="null" selected disabled></option>
                    <option value="Edit">Edit</option>
                    <option value="Delete">Delete</option>
                </select>
                <button type="submit" name="accept" value="accept">Accept</button>
            </form> <br>
            
            <?php
            if (isset($_POST['accept'])) {
                $connection = "localhost";
                $username = "root";
                $password = "";
                $base = "projekt";
                $dbc = mysqli_connect($connection, $username, $password, $base) or die('Error cant connect to database');

                if ($_POST['choice'] == null || isset($_POST['action']) != true) {
                    echo "One or more values have not been selected!!";
                    exit();
                } else {
                    $choice = $_POST['choice'];
                    $action = $_POST['action'];
                }

                $query = "SELECT * FROM news";
                $choiceCheck = 0;

                $result = mysqli_query($dbc, $query) or die('Query error');
                if ($result) {
                    while ($row = mysqli_fetch_array($result)) {
                        if ($choice == $row['id']) {
                            $choiceCheck = 1;
                            $idEdit = $row['id'];
                            $titleEdit = $row['title'];
                            $dscEdit = $row['description'];
                            $categoryEdit = $row['category'];
                            $archiveEdit = $row['archive'];
                            $imageDelete = $row['image'];
                            break;
                        }
                    }
                }

                if ($choiceCheck == 0) {
                    echo "No such id in database!!";
                    exit();
                }

                if ($action == "Delete") {
                    $query = "DELETE FROM news WHERE id = $idEdit";
                    $result = mysqli_query($dbc, $query) or die('Query error');

                    $path = "images/$imageDelete";
                    unlink($path);

                    echo("<meta http-equiv='refresh' content='1'>");
                } 
                else {
                    session_start();
                    $_SESSION['idUpdate'] = $idEdit;

                    echo"Imput new parameters to replace old ones leave empty if change to that parameter should not be edited <br>";
                    echo"ID = $idEdit <br>";
                    echo"<form method='post' action='update.php' enctype='multipart/form-data'> 
                    <label for='title'>Title:</label> <br>
                    <input type='text' name='title' id='title'> <br>
    
                    <label for='desc'>Description:</label> <br>
                    <textarea name='desc' id='desc' cols='50' rows='10'></textarea> <br>
    
                    <label for='bodytext'>Full text:</label> <br>
                    <textarea name='bodytext' id='bodytext' cols='50' rows='20'></textarea> <br>
    
                    <label for='pic'>Picture:</label> <br>
                    <input type='file' name='pic' id='pic'> <br>
    
                    <label for='cat'>Category:</label> <br>
                    <select name='cat' id='cat'>
                        <option value='Release'>Release news</option>
                        <option value='Event'>Event news</option>
                    </select> <br>
    
                    <label for='archive'>Archive:</label> <br>
                    <select name='archive' id='archive'> <br>
                        <option value='DontArchive'>Don't Archive</option>
                        <option value='Archive'>Archive</option>
                    </select> <br>
    
                    <button type='reset' value='reset'>Reset</button>
                    <button type='submit' value='accept'>Accept</button>
                    </form>";
                }
                
                mysqli_close($dbc);
            }
            ?>
        </section>
        <footer>
            <p>Dario Šaka dsaka@tvz.hr 2022 <img src="images/menacing.png"></p> 
        </footer>
    </div>
</body>

</html>