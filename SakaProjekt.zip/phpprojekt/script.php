<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Prewiev page</title>
</head>

<body class="main">
    <div>
        <header>
            <h1>Jojo's bizzare advantures <img src="images/menacing.png"></h1>
            <section class="login">
                <?php
                    error_reporting(E_ALL & ~E_NOTICE); 
                    session_start();
                    if($_SESSION['power'] == "none") {
                        echo'<form method="post" action="login.php">
                                <button type="submit" value="login">Login</button>
                            </form>
                            <form method="post" action="register.php">
                                <button type="submit" value="register">Register</button>
                            </form>';
                    }
                    else {
                        echo $_SESSION['username'];
                        if(isset($_POST['logout'])) {
                            $_SESSION['power'] = "none";
                            echo("<meta http-equiv='refresh' content='1'>");
                        }

                        echo '<form method="post"> 
                                <button type ="submit" id="logout" name="logout" value="logout">Logout</button>
                            </form>';
                        
                    }
                ?>
                
            </section> <br>
            <nav>
                <ul>
                <?php 
                    if($_SESSION['power'] == "none" || $_SESSION['power'] == "user") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>';
                    }
                    else if($_SESSION['power'] == "admin") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>
                        <a href="unos.php"><li>Input</li></a>
                        <a href="admin.php"><li>Administration</li></a>';
                    }
                ?>
                </ul>
            </nav>
        </header>
        <article>
            <?php
            if ($_POST['title'] != " " && $_POST['desc'] != " " && $_POST['bodytext'] != " " && isset($_POST['cat']) && $_FILES['pic']['error'] == 0) {
                $title = $_POST['title'];
                $dsc = $_POST['desc'];
                $txt = $_POST['bodytext'];
                $category = $_POST['cat'];
                

                $pic = $_FILES["pic"]["name"];
                $target_dir = "images/";
                $target_file = $target_dir . basename($pic);
                $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

                if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                    echo "Picture format must be (jpg/png/jpeg/gif)!!!!";
                } else {
                    move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file);
                    echo "<h1>$title</h1><br>";
                    echo "<p>$dsc</p><br>";
                    echo "<img src='images/" . $pic . "'/>";
                    echo "<p>$txt</p><br>";
                    echo "<p>Category: $category</p><br>";

                    $connection = "localhost";
                    $username = "root";
                    $password = "";
                    $base = "projekt";
                    $dbc = mysqli_connect($connection, $username, $password, $base) or die('Error cant connect to database');

                    $archive = 0;
                    if(isset($_POST['archive'])) {
                        $archive = 1;
                    }

                    $title = str_replace("'", "''", $title);
                    $dsc = str_replace("'", "''", $dsc);
                    $txt = str_replace("'", "''", $txt);

                    $query = "INSERT INTO news (title, image, description, text, category, archive) VALUES(?, ?, ?, ?, ?, '$archive')";
                    $stmt = mysqli_stmt_init($dbc);

                    if (mysqli_stmt_prepare($stmt, $query)) {
                        mysqli_stmt_bind_param($stmt, 'sssss', $title, $pic, $dsc, $txt, $category);
                        mysqli_stmt_execute($stmt);
                    }
                    mysqli_close($dbc);
                } 
            }
            else {
                echo"One or more values has not been set unable to generate new post!!";
            }
            ?>
        </article>

        <footer>
            <p>Dario Šaka dsaka@tvz.hr 2022 <img src="images/menacing.png"></p> 
        </footer>
    </div>
</body>

</html>