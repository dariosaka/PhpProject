<!DOCTYPE html>
<html  id="homeanchor" lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Main page</title>
</head>

<body class="main">
    <div>
        <header>
            <h1>Jojo's bizzare advantures <img src="images/menacing.png"></h1>
            <section class="login">
                <?php 
                    error_reporting(E_ALL & ~E_NOTICE);
                    session_start();
                    if(!isset($_SESSION['power'])) {
                        $_SESSION['power'] = "none";
                    }
                    if($_SESSION['power'] == "none") {
                        echo'<form method="post" action="login.php">
                                <button type="submit" value="login">Login</button>
                            </form>
                            <form method="post" action="register.php">
                                <button type="submit" value="register">Register</button>
                            </form>';
                    }
                    else {
                        echo $_SESSION['username'];
                        if(isset($_POST['logout'])) {
                            $_SESSION['power'] = "none";
                            echo("<meta http-equiv='refresh' content='1'>");
                        }

                        echo '<form method="post"> 
                                <button type ="submit" id="logout" name="logout" value="logout">Logout</button>
                            </form>';
                        
                    }
                ?>
                
            </section> <br>
            <nav>
                <ul>
                <?php 
                    if($_SESSION['power'] == "none" || $_SESSION['power'] == "user") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>';
                    }
                    else if($_SESSION['power'] == "admin") {
                        echo'<a href="index.php#homeanchor"><li>Home</li></a>
                        <a href="news.php#releaseanchor"><li>Release news</li></a>
                        <a href="news.php#eventanchor"><li>Event news</li></a>
                        <a href="unos.php"><li>Input</li></a>
                        <a href="admin.php"><li>Administration</li></a>';
                    }
                ?>
                </ul>
            </nav>
        </header>
        <h2>Parts</h2>
        <section class="parts">
            <form method="post" action ="part.php">
                <button type="submit" value="bubble" id="bubble" name="bubble">
                <article>
                    <img src="images/Part8.jpg" alt="Part8">
                    <p>JoJolion</p>
                </article>
                </button>

                <button type="submit" value="tusk" id="tusk" name="tusk">
                <article>
                    <img src="images/Part7.jpg" alt="Part7">
                    <p>Steel Ball Run</p>
                </article>
                </button>

                <button type="submit" value="stone" id="stone" name="stone">
                <article>
                    <img src="images/Part6.jpg" alt="Part6">
                    <p>Stone Ocean</p>
                </article>
                </button>

                <button type="submit" value="gold" id="gold" name="gold">
                <article>
                    <img src="images/Part5.jpg" alt="Part5">
                    <p>Vento Aureo</p>
                </article>
                </button>

                <button type="submit" value="diamond" id="diamond" name="diamond">
                <article>
                    <img src="images/Part4.jpg" alt="Part4">
                    <p>Diamond is Unbreakable</p>
                </article>
                </button>
            </form>
        </section>

        <h2>News</h2>
        <h3>Release news</h3>
        <section class="news">
            <?php 
                $connection = "localhost";
                $username = "root";
                $password = "";
                $base = "projekt";
                $dbc = mysqli_connect($connection, $username, $password, $base) or die('Error cant connect to database');


                $query = "SELECT * FROM news WHERE category = 'Release' ORDER BY id DESC LIMIT 4";

                $result = mysqli_query($dbc, $query) or die('Query error');

                if($result) {
                    while($row = mysqli_fetch_array($result)) {
                        if($row['archive'] == 0) {
                            echo "
                            <article>
                                <img src='images/" . $row['image'] . "'/>
                                <h3>" . $row['title'] . "</h3> 
                            </article>
                            ";
                        }
                    }
                }
                mysqli_close($dbc);
            ?>
        </section>

        <h3>Event news</h3>
        <section class="news">
            <?php 
                $connection = "localhost";
                $username = "root";
                $password = "";
                $base = "projekt";
                $dbc = mysqli_connect($connection, $username, $password, $base) or die('Error cant connect to database');


                $query = "SELECT * FROM news WHERE category = 'Event' ORDER BY id DESC LIMIT 4";

                $result = mysqli_query($dbc, $query) or die('Query error');

                if($result) {
                    while($row = mysqli_fetch_array($result)) {
                        if($row['archive'] == 0) {
                            echo "
                            <article>
                                <img src='images/" . $row['image'] . "'/>
                                <h3>" . $row['title'] . "</h3> 
                            </article>
                            ";
                        }
                    }
                }
                mysqli_close($dbc);
            ?>
        </section>

        <footer>
            <p>Dario Šaka dsaka@tvz.hr 2022 <img src="images/menacing.png"></p> 
        </footer>
    </div>
</body>

</html>